<?php
$environment = 'devel';
$cwa_url = 'http://cwa-dev-jenkins.test.buddymedia.com';
$path_url = 'http://cbdemo.test.buddymedia.com/'.$environment.'/';
$app_id = 244931835547498;
?>
<div>
Environment: <?php echo $environment; ?><br />
CWA URL: <?php echo $cwa_url; ?><br />
Path URL: <?php echo $path_url; ?><br />
App Id: <?php echo $app_id; ?><br />
</div>

