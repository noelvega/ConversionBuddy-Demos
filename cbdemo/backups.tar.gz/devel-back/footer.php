					<?php
						//echo '<pre>';
						//var_dump($_SESSION['jcart']);
						//echo '</pre>';
					?>
				</div>
	
				<div class="clear"></div>
			</div>
		</div>
	</body>
</html>